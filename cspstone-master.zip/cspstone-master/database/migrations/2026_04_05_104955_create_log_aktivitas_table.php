<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('log_aktivitas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->string('aktivitas');
            $table->string('ip_address', 45)->nullable();
            $table->text('detail')->nullable();
            $table->timestamps();
            
            $table->index('created_at');
            $table->index('user_id');
            $table->index('aktivitas');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('log_aktivitas');
    }
};